
	<div class="navbar navbar-fixed-top">
	
	<div class="navbar-inner">
		
		<div class="container">
			
			<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</a>
			
			<div class="brandLogo">
				<img src="../img/bajaj-logo.png" alt=""/>
				<a class="brand" href="index.php">
					<h2 class="text-primary bajajBlue">Electronic Parts Catalog - Admin</h2>
				</a>		
			</div>

 <div class="nav-collapse">
    <ul class="nav pull-right">
        <li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><i
            class="icon-cog"></i> Account <b class="caret"></b></a>
            <ul class="dropdown-menu">
                <li><a href="javascript:logout();">Logout</a></li>
            </ul>
        </li>
    </ul>

</div>
	
		</div> <!-- /container -->
		
	</div> <!-- /navbar-inner -->
	
	</div> <!-- /navbar -->

