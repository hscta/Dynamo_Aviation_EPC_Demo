<?php

header("Location: login.php"); /* Redirect browser to login page if user not loggedin */

?>