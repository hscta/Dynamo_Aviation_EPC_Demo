<script>
function openwindow()
{
	window.open("http://gladminds.co/bajaj/user_dealer/tyre-assembly/MLG%20with%20training%20scenario.training.description.html","mywindow","menubar=1,resizable=1,width=500,height=600");
}
</script>
<h1><a href="http://gladminds.co/bajaj/user_dealer/tyre-assembly/MLG%20with%20training%20scenario.htm"> Training Module 1: Tyre Assembly</a></h1>

<h3 style="margin-top: 15px;"> <a onclick="openwindow();" style="cursor:pointer;padding-top:10px;color:#8CC7E3;">a) Training Procedures </a></h3>


<a href="http://gladminds.co/bajaj/user_dealer/tyre-assembly/MLG%20with%20training%20scenario.htm"><img src="pages/tyre.jpg" style="width:50%;margin-top:20px;" / ></a>